package br.iesb.meuprograma.entidades;

public class Unidade {
  int id;
  int unidade;
  String bloco;
  double areaComum;
  double areaPrivativa; 
  String vaga1;
  String vaga2;
  String vaga3;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUnidade() {
        return unidade;
    }

    public void setUnidade(int unidade) {
        this.unidade = unidade;
    }

    public String getBloco() {
        return bloco;
    }

    public void setBloco(String bloco) {
        this.bloco = bloco;
    }

    public double getAreaComum() {
        return areaComum;
    }

    public void setAreaComum(double areaComum) {
        this.areaComum = areaComum;
    }

    public double getAreaPrivativa() {
        return areaPrivativa;
    }

    public void setAreaPrivativa(double areaPrivativa) {
        this.areaPrivativa = areaPrivativa;
    }

    public String getVaga1() {
        return vaga1;
    }

    public void setVaga1(String vaga1) {
        this.vaga1 = vaga1;
    }

    public String getVaga2() {
        return vaga2;
    }

    public void setVaga2(String vaga2) {
        this.vaga2 = vaga2;
    }

    public String getVaga3() {
        return vaga3;
    }

    public void setVaga3(String vaga3) {
        this.vaga3 = vaga3;
    }

  
}
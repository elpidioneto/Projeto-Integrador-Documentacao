package br.iesb.meuprograma.entidades;

public class Enxoval {
    
    int id;
    int espacoId; 
    String nome;
    double valor;
    int quantidade; 

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEspacoId() {
        return espacoId;
    }

    public void setEspacoId(int espacoId) {
        this.espacoId = espacoId;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double Valor) {
        this.valor = Valor;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    
    
    
}
